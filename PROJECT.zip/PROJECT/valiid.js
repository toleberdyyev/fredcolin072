$(document).ready(function(){
var pattern = /^[a-zA-Z0-9]{6,40}$/i;
var password = $('#password');
password.blur(function(){
  if (password.val() !=''){
    if(password.val().search(pattern)==0){
      $('#valid2').text("");
      $('#submit').attr('disabled',false);
      password.removeClass('error').addClass('ok');
    }else {
      $('#valid2').text('Password is not correct');
      document.getElementById('valid2').style.color ='#a42127';
      document.getElementById('password').style.border ='2px solid #a42127'
      $('#submit').attr('disabled',true);
      password.addClass('ok');
}
}else {
$('#valid2').text( "Field password is empty");
document.getElementById('valid2').style.color ='#a42127'
document.getElementById('password').style.border ='2px solid #a42127'
mail.addClass('error');
$('#submit').attr('disabled',true);
}
});
});

$(document).ready(function(){
var pattern = /^[a-zA-Z0-9]{6,40}$/i;
var password2 = $('#password2');
password2.blur(function(){
  if (password2.val() !=''){
    if(password2.val().search(pattern)==0){
      $('#valid3').text("");
      $('#submit').attr('disabled',false);
      password.removeClass('error').addClass('ok');
    }else {
      $('#valid3').text('Confirm password is not correct');
      document.getElementById('valid3').style.color ='#a42127';
      document.getElementById('password2').style.border ='2px solid #a42127'
      $('#submit').attr('disabled',true);
      password.addClass('ok');
}
}else {
$('#valid3').text( "Field confirm password is empty");
document.getElementById('valid3').style.color ='#a42127'
document.getElementById('password2').style.border ='2px solid #a42127'
mail.addClass('error');
$('#submit').attr('disabled',true);
}
});
});
