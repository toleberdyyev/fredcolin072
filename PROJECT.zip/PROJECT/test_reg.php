<html><head>
<title>hackount.kz</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<style type="text/css">
body{
font-family: arial !important;
font-weight: 600 !important;

}.text-center{
font-family: arial !important;
color: white !important;

}
</style>
</head><body>
<?php 
session_start();

?>
<!--?php // вся процедура работает на сессиях. Именно в ней хранятся данные
пользователя, пока он находится на сайте. Очень важно запустить их в самом
начале странички!!! session_start(); ?-->
<div class="cover">
<div class="background-image-fixed cover-image" style="background-image : url('http://www.designvertise.com/wp-content/uploads/2014/05/Space-45-Night-by-Seth-Eckert.gif')"></div>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="section">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1 class="text-center">
<img src="profile/user_image/logo_white.png" style="width: 100px;">
<br>
<b class="bid">hackount.kz</b>
</h1>
<div class="section">
<div class="container">
    <div class="row">
        <div class="col-md-4 hidden-xs"></div>
        <div class="col-md-4 login-box" style="box-shadow: none;">
            <br>
             <?php
        session_start();//  вся процедура работает на сессиях. Именно в ней хранятся данные  пользователя, пока он находится на сайте. Очень важно запустить их в  самом начале странички!!!
    if (isset($_POST['login'])) { $login = $_POST['login']; if ($login == '') { unset($login);} } //заносим введенный пользователем логин в переменную $login, если он пустой, то уничтожаем переменную
        if (isset($_POST['password'])) { $password=$_POST['password']; if ($password =='') { unset($password);} }
        //заносим введенный пользователем пароль в переменную $password, если он пустой, то уничтожаем переменную
    
        //если логин и пароль введены,то обрабатываем их, чтобы теги и скрипты не работали, мало ли что люди могут ввести
        $login = stripslashes($login);$login = htmlspecialchars($login);
        $password = stripslashes($password);$password = htmlspecialchars($password);
    //удаляем лишние пробелы
        $login = trim($login);$password = trim($password);
    // подключаемся к базе
        include ("db.php");// файл bd.php должен быть в той же папке, что и все остальные, если это не так, то просто измените путь 
     
    $result = mysql_query("SELECT * FROM users WHERE login='$login'",$db); //извлекаем из базы все данные о пользователе с введенным логином
        $myrow = mysql_fetch_array($result);    
        if (empty($myrow['password']))
        {
        //если пользователя с введенным логином не существует
              echo "<center><img src='img/error.png' style='width:100px;height:100px;'></center><br>";
        echo "<center><p>Введенный вами логин<br> или парол не корректный.</p></center>";
        }
        else {
        //если существует, то сверяем пароли
        if ($myrow['password']==$password) {
        //если пароли совпадают, то запускаем пользователю сессию! Можете его поздравить, он вошел!
        $status="online";
        $_SESSION['login']=$myrow['login']; 
        $_SESSION['id']=$myrow['id'];
        $user_id=$myrow['id'];
        $_SESSION['password']=$myrow['password'];
        if ($myrow['login']=='toleberdyyev'){$_SESSION['admin']='toleberdyyev';}
        $sql=mysql_query("UPDATE bidaction.users SET online_status='$status'  WHERE users.id='$user_id' ");
      
        header('location:profile/index.php');//эти данные очень часто используются, вот их и будет "носить с собой" вошедший пользователь
        }
     else {
        //если пароли не сошлись
        echo "<center><img src='img/error.png' style='width:100px;height:100px;'></center><br>";
        echo "<center><p>password is incorrect </p></center>";
       

        }
        }

  ?>
  <br>
<input class="form-control" type="button" onclick="history.back()" value="Back" style="background-color: #5BC0DE;color: white;border:hidden;">
        <br>

        </div>

        <div class="col-md-4 hidden-xs"></div>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


</body></html>