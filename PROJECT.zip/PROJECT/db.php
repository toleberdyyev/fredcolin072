<?php
$db = mysql_connect("localhost","root","123");
mysql_select_db ("bidaction",$db);
?>