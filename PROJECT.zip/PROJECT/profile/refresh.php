<?php 
header("location:profile_settings.php");
 ?>