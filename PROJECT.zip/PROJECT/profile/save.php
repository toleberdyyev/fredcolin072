<?php
session_start();
$ava=$_POST['photo'];
$user_id=$_SESSION['id'];
$log= $_SESSION['login'];
$connect=mysql_connect('localhost','root','123')or die(mysql_error());
mysql_select_db('bidaction');
if (isset($_POST['enter'])){
$date=date('F j, Y g:i a ');
$text=$_POST['post_text'];

if(!empty($text)){
$result2 = mysql_query("INSERT INTO posts (id,user,login,p_text,p_date,photo) VALUES(NULL,'$user_id','$log','".addslashes($text)."','$date','$ava')")or die(mysql_error());
	header("location:index.php");}
else{
	header("location:index.php");
}



}

?>