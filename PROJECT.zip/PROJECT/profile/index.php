<!--  PROFILE  -->
<html><head>

<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Ubuntu&subset=cyrillic' rel='stylesheet' type='text/css'>
<link rel="shortcut icon" href="user_image/logo_white.png" type="image/png">
<style type="text/css">
  body{
background-color: #3E3E3E !important;
font-family: 'Ubuntu', sans-serif !important;
}.text-primary{
  font-family: arial !important;
}.col-md-3.col-sm-4{
  border-radius: 5px 0px 0px 0px !important;
  background-color: white !important; 
    padding-left: 0px;
  padding-right: 0px;
}.col-md-5{
  background-color: white;
}
.navbar{
  position: fixed !important;
  width: 100%;
  border: hidden !important;
  box-shadow: 0em 0.4em 8px #000 !important;
}.row{
  margin: auto!important;
}#cancel{
  width: 85px;
  float: left !important;
  background-color: #337CBB; 
  color: white;
  border: hidden;
  margin-top: -10px;
}.delete_post{
  float: left; 
  background-color: #eaeaea;
  color: #666666;
  border-radius: 0px 0px 3px 3px;  
  border:hidden;
  margin-top: -15px;
  opacity: 0.5;
  width: 25px;
}.delete_post:hover{
  background-color:#ff4d4d;
  color: white;
  opacity: 1;
}#ava_back{
 border-radius:4px 0px 0px 0px !important;
  
  display: inline-block;
  width: 100%;
  height:135px;
  background-position: center center;
  background-size: cover;
}#ava{
  margin-top: -25px !important;
  border:5px solid white;
  border-radius: 50px;
  display: inline-block;
  width: 100px;
  height: 100px;
  margin-top: 5px;
  background-position: center center;
  background-size: cover;
 
  
}#post{

  margin-top: 5px;
  height: auto;

}#post textarea{
  padding:0px;
  background-color: #F5F5F5;
}.post_time{
  font-size: 13px;
  color:#337CBB;
  margin-top: -8px;
  padding-left: 70px; 
}#post_text{
  resize: none;
  font-size: 15px;

}.post_pole{
  
  border-radius: 3px 3px 3px 0px !important;

}#edit{
  border: hidden;
  border-radius: 0px 0px 3px 3px;

}#save{
  border: 1px solid #eaeaea;
  border-radius: 0px 0px 3px 3px;
  float: right;
  background-color:white;
  height: 23px;
  padding: 0px 2px 0px 2px; 
  margin-right: 3px;
}#save:hover{
    box-shadow: 0em 0.2em 5px rgba(122,122,122,0.5);

}.login_in_post{
  padding-left:70px;
  padding-bottom:-55px;
  padding-top: 5px;
font-family: 'Ubuntu', sans-serif;
font-weight: 500;
}.footer{
  margin: auto;
}.thumb{ 
  border-radius: 23px;
    display: inline-block;
    width: 46px;
    height: 46px;
    margin-bottom: 10px;
    margin-top: 0px;
    float: left;
    background-position: center center;
    background-size: cover;
}.edit_btn:hover{
  opacity: 1;
}.posty{
  padding-left:0px !important
}

  
</style>
    <title>My Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="profile.css" rel="stylesheet" type="text/css">
  </head>
<?php
session_start();
include "../db.php";
$log= $_SESSION['login'];
$result=mysql_query("SELECT * FROM users WHERE login='$log'",$db);
$myrow=mysql_fetch_array($result);
$ava=$myrow['photo'];
$back=$myrow['photo_back'];

if (empty($_SESSION['login']) or empty($_SESSION['id'] or empty($_SESSION['password'])) )
{
header("location:../index.php");
}             
?>
  <body>
    <div class="navbar navbar-default navbar-static-top" class="navbar">
      <div class="container">
        <div class="navbar-header" >
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>

            </button>
         <a class="navbar-brand" href="../home.php"><h3 style="margin-top: -11px;"><img style="margin-top:-5px;width: 50px;" src="user_image/small_logo.png">hackount.kz</h3></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="../home.php">Main page</a> 
            </li>
             <li>
              <a href="../game_dev/index.php">Game dev</a> 
            </li>
            
            <li class="active dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" style="color:#337CBB;">@<?php echo $myrow['login']." ";?><i class="fa fa-caret-down"><br></i></a>
              <ul class="dropdown-menu" role="menu" style="border: hidden;">
                <li>
                  <a href="logout.php">Выйти</a>
                </li>
                <li>
                  <a href="profile_settings.php"><img src="user_image/settings.png" style="width: 20px;float: right;">Настройки</a>
                </li>
                <?php 
                  if ($myrow['roots']==1){
                    echo "<li>
                        <a href='admin_set.php'>admin settings</a>
                    </li>";
                  }
                 ?>
              </ul>
            </li>
          
            
          </ul>
        </div>
      </div>
    </div>
    <div class="section">       
      <div class="container"><br><br>
        
        <div class="row">
          <div class="col-md-2 col-sm-1">
          </div>
          <div class="col-md-3 col-sm-4">
          
            
            <div id="ava_back" style="background-image: url(http://localhost/PROJECT/profile/<?php echo $back;?>" title="It is me"></div><center>
            <div>
                <div id="ava" style="background-image: url(http://localhost/PROJECT/profile/<?php echo $ava;?>" title="It is me"></div>
            </div>
           
            

              <h3 class="text-primary"><?php echo $myrow['name']."<br>".$myrow['surname'];?></h3>
              <br>
              <table class="table" style="padding: 10px;">
                <thead>
                  <tr></tr>
                </thead>
                <tbody>
                  <tr>
                    <td style="text-align: right;"><b>Phone</b></td>
                    <td><?php echo $myrow['phone']; ?></td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td style="text-align: right;"><b>Birth Date</b></td>
                    <td><?php echo $myrow['age']; ?></td>
                  </tr>
                  <tr>
                    <td style="text-align: right;"><b>City</b></td>
                    <td><?php echo $myrow['city']; ?></td>
                  </tr>
                </tbody>
              </table>  
            </center>
            
          </div>
          <div class="col-md-5 col-sm-6"  class='posty'style="border-left:2px solid #3E3E3E !important;padding: 0px !important;background-color: transparent;">

        
          <div class="col-md-12" style="padding: 10px !important;background-color: white;">
              <br>
            <blockquote style="background-color: #F8F8FA">
              <p><?php if($myrow['roots']==1){
                echo "Admin";
              }else{
                echo "Welcome again :)";
              }

               ?></p>
              <footer><?php echo $myrow['online_status']; ?></footer>
            </blockquote>
            <table class="table" style="background-color: #F8F8FA">
                <tr>
                  <td>email</td>
                  <td><?php echo $myrow['email']; ?></td>
                </tr>
                <tr>
                  <td>My phone number</td>
                  <td><?php echo $myrow['phone']; ?></td>
                </tr>
                
            </table>
      
      <form method="post" action="save.php">

      <input name="photo"  value="<?php echo $ava; ?>" type="hidden"></input>
   <textarea class="form-control input-sm" id="content_txt" type="text"  rows ="3" id="post_text"  maxlength="138" name="post_text" placeholder="Что у вас нового ?" style="resize: none !important;border-radius: 0px !important; "></textarea><br><span id="demo"><input class="form-control" name="enter" type="submit" id="cancel" value="post"><p id="message" style="float: right;color: gray"></p>
   <br><br></form>
          </div>
        


<?php 
  include "result.php";  
  ?>
</div>
<script type="text/javascript">
function edsit(o){
  var id_index= o.id
  var id= id_index.substring(0,1)
  var id_text=id+"_text"
  console.log(id)
  o.style.opacity=1;
  document.getElementById(id).innerHTML="<input type='image' value='save' id='save' src='user_image/save.png'>"
  document.getElementById(id_text).readOnly = false;
  document.getElementById(id_text).style.background="white";



}

var area = document.getElementById("content_txt");
var message = document.getElementById("message");
var maxLength = 140;
var checkLength = function() {
    if(area.value.length < maxLength) {
        message.innerHTML = (maxLength-area.value.length) + " symbols";
    }
}
setInterval(checkLength, 300);
</script>


             
             </div>

                <div class="col-md-1 col-sm-1"></div>
              </li>
            </ul>
          </div>
          <br><br>
        </div>
      </div>

    </div>
  

</body></html>