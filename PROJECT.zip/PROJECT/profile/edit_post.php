<?php 
$post_id=$_GET['id_post'];
$post_text=$_GET['post_text'];
$date=date('D d.m.y g:i a ');
include '../db.php';
$sql=mysql_query("UPDATE bidaction.posts SET p_text='$post_text'  WHERE posts.id='$post_id' ");
$sql=mysql_query("UPDATE bidaction.posts SET p_date='$date'  WHERE posts.id='$post_id' ");
header("location:index.php")


?>