<?php 
if(isset($_GET['level'])){
	include "../db.php";
	$q_id=$_GET['q_id'];
	$level=$_GET['level'];
	$sql0=mysql_query("UPDATE admin_orders SET checked=1  WHERE id='$q_id' ");
	$sql1=mysql_query("UPDATE admin_orders SET level='$level'  WHERE id='$q_id' ");
	if($sql1 and $sql0){ header("location:admin_set.php") ;}

}

if(isset($_POST['q_id'])){
	$q_id=$_POST['q_id'];
	echo $q_id;
	include "../db.php";
	$res=mysql_query("DELETE FROM admin_orders WHERE id='$q_id'",$db);
	if($res=="TRUE"){
		header("location:admin_set.php");
	}
}

 ?>