  if (isset($_GET["id"])) {
    if ($_GET["id"] == 0) {
      $log= $_SESSION['login'];
      $result=mysql_query("SELECT * FROM users WHERE login='$log'",$db);
      $myrow=mysql_fetch_array($result);
    }else{
      $id= $_GET['id'];
      $result=mysql_query("SELECT * FROM users WHERE id='$id'",$db);
      $myrow=mysql_fetch_array($result);
    }
  }