<!DOCTYPE html>
<html>
<head>
<meta charset=utf-8>
<title>test</title>

<style>
.outer {
	margin-top: 50px;
	width: 100px;
	height: auto;
	position: absolute;
	top: 50px;
	left: 10px;
}
.inner {
	height: 500%;
	width: 100%;
	position: absolute;
	top: -200%;
}  
  
img {
	display: block;
	position: absolute;
	border: 1px solid black;
	width: 100%;
	height: auto;
	margin: auto;
	 /* для наглядности */
}
</style>
</head>
<body>
<?php 
include "upld.php";
?>
	<div class="outer">
		<div class="inner">
			<?php 
			echo "<img src='".$url."'>";
			?>
		</div>
	</div>
	<form action="ava.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
</form>  
	  
	
	
</body>
</html>
