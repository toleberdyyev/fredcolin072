<!--  ADMIN SETTINGS -->
<html><head>

<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Ubuntu&subset=cyrillic' rel='stylesheet' type='text/css'>
<script src="http://www.google.com/jsapi"></script>
<link rel="shortcut icon" href="user_image/logo_white.png" type="image/png">
<style type="text/css">
  body{
background-color: #3E3E3E !important;
font-family: 'Ubuntu', sans-serif !important;
}.text-primary{
  font-family: arial !important;
}.col-md-12{
  margin-top: 35px;

    padding-left: 0px;
  padding-right: 0px;
}#panel{
  margin-left: 5px !important;
  border-radius: 0px 5px 0px 0px!important;
  background-color: white !important;
  padding-bottom: 7px;

  margin-left: 0px !important;

}
.navbar{
  position: fixed !important;
  width: 100%;
  border: hidden !important;
  box-shadow: 0em 0.4em 8px #000 !important;
}.row{
  margin: auto!important;
}#cancel{
  width: 85px;
  float: left !important;
  background-color: #337CBB; 
  color: white;
  border: hidden;
  margin-top: -10px;
}.delete_post{
  float: left; 
  background-color: #eaeaea;
  color: #666666;
  border-radius: 0px 0px 3px 3px;  
  border:hidden;
  margin-top: -15px;
  opacity: 0.5;
  width: 25px;
}.delete_post:hover{
  background-color:#ff4d4d;
  color: white;
  opacity: 1;
}#ava_back{
  
  display: inline-block;
  width: 100%;
  height:35%;
  background-position: center center;
  background-size: cover;
}#ava{
  margin-top: -25px !important;
  border:5px solid white;
  border-radius: 50px;
  display: inline-block;
  width: 100px;
  height: 100px;
  margin-top: 5px;
  background-position: center center;
  background-size: cover;
 
  
}#post{
  background-color: white;
  margin-top: 5px;
  height: auto;
}#post textarea{
  padding: 15px 8px 15px 8px;
  background-color: #F5F5F5;
}.post_time{
  font-size: 13px;
  color:#337CBB;
  margin-top: -8px;
  padding-left: 70px; 
}#post_text{
  resize: none;
  font-size: 15px;

}.post_pole{
  
  border-radius: 3px 3px 3px 0px !important;

}#edit{
  border: hidden;
  border-radius: 0px 0px 3px 3px;

}#save{
  border: 1px solid #eaeaea;
  border-radius: 0px 0px 3px 3px;
  float: right;
  background-color:white;
  height: 23px;
  padding: 0px 2px 0px 2px; 
  margin-right: 3px;
}#save:hover{
    box-shadow: 0em 0.2em 5px rgba(122,122,122,0.5);

}.login_in_post{
  padding-left:70px;
  padding-bottom:-55px;
  padding-top: 5px;
font-family: 'Ubuntu', sans-serif;
font-weight: 500;
}.footer{
  margin: auto;
}.thumb{ 

   
    display: inline-block;
    width: 100%;
    height:100px;
   
 ;
    background-position: center center;
    background-size: cover;
    padding: 0px;
}.edit_btn:hover{
  opacity: 1;
}#upload,#delete{
  color: white;
  background-color: #337CBB;
  border:hidden;

}#delete{
  color: white;
  background-color: #EA4335 ;
    border:hidden;

}

  
</style>
    <title>Admin settings</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="profile.css" rel="stylesheet" type="text/css">
    <script src="http://www.google.com/jsapi"></script>
        <script language="javascript">
            google.load('prototype', '1.6.0.2');
        </script>
  </head>
<?php
if(isset($_POST['level']) and ($_POST['level']!='choose')){header('location:admin_function.php?level='.$_POST['level'].'&q_id='.$_POST['q_id']);}
session_start();
include "../db.php";
$log= $_SESSION['login'];
$result=mysql_query("SELECT * FROM users WHERE login='$log'",$db);
$myrow=mysql_fetch_array($result);
if ($myrow['roots']!=1){
  header('location:index.php');
}
$ava=$myrow['photo'];
$back=$myrow['photo_back'];
if($_SESSION['admin']!='toleberdyyev'){header("location:../index.php");}
if (empty($_SESSION['login']) or empty($_SESSION['id'] or empty($_SESSION['password'])) )
{
header("location:../index.php");
}             
?>
  <body>
    <div class="navbar navbar-default navbar-static-top" class="navbar">
      <div class="container">
        <div class="navbar-header" >
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>

            </button>
         <a class="navbar-brand" href="../home.php"><h3 style="margin-top: -11px;"><img style="margin-top:-5px;width: 50px;" src="../profile/user_image/logo_white.png">hackount.kz</h3></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="../home.php">Main page</a> 
            </li>
             <li >
              <a href="../game_dev/index.php" >Game dev</a> 
            </li>
            
            <li class="active">
              <a href="../profile/index.php" style="color:#337CBB;">@<?php echo $myrow['login']; ?></a> 
            </li>
          
            
          </ul>
        </div>
      </div>
    </div>
    <div class="section">       
      <div class="container">
        <div class="row">
      
     
     <div class="col-md-12" style="padding: 0px;"> <div id="ava_back" style="background-image: url(http://localhost/PROJECT/img/statistik.gif)"><center><h1 style="color:white;margin-top: 40px;font-size:100px;">Admin settings:<br></h1><p style="color:white;margin-top:-22px;font-size: 30px;">users game developing</p></center></div>
  <?php 

include "../db.php";
$id=$_SESSION['id'];
$servername = "localhost";
$username = "root";
$password = "123";
$dbname = "bidaction";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$index=0;
$sql = " SELECT * FROM admin_orders WHERE checked=0 ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
 echo ' <div class="table-responsive" style="background-color:white;"><table class="table table-striped table-bordered table-condensed" style="padding: 10px;padding-left:10px;" >
          <tbody>
          <tr style="color:gray;"><td>#</td><td>author</td>
              <td>question</td>
              <td>true</td>
              <td>false</td>
              <td>false</td>
              <td>false</td>
              <td>upload</td>
              <td>delete</td>
              </tr>
          ';
    while($row = $result->fetch_assoc()) {
      $index++;
       echo ' 
                  <tr>
                    <td>'.$index.'</td>
                    <td style="color:#337CBB;">'.$row['author'].'</td>
                    <td>'.$row['question'].'</td>
                    <td>'.$row['qt'].'</td>
                    <td>'.$row['f1'].'</td>
                    <td>'.$row['f2'].'</td>
                    <td>'.$row['f3'].'</td>
                    <td><form action="admin_set.php" method="post">
                    <select class="form-control" name="level" required>asdasd
                    <option >choose</option>
                    <option value="easy" >Easy</option>
                    <option value="normal">Normal</option>
                    <option value="hard">Hard</option>
                  </select>
                <input type="hidden" name="q_id" value="'.$row['id'].'">
                <button type="submit" class="btn btn-default" style="width:100%" id="upload">upload </button></form></td>
                    <td><form action="admin_function.php" method="post">
                     <input type="hidden" name="q_id" value="'.$row['id'].'">
                     <button type="submit" class="btn btn-default"  style="width:100%" id="delete">delete </button></form></td>
                  </tr>
                  
             ';
        
    }echo "</tbody></table></div>";
} else {
    echo "<br><br>";
    echo "<center> <p style='color:#888686;'>No any orders from clients :(</p></center>";
}
$conn->close();
?>

          </div>
        
        </div>
      </div>

    </div>
  
 <script type="text/javascript" language="javascript">
            resizeIt = function() {
              var str = $('post_text').value;
              var cols = $('post_text').cols;

              var linecount = 0;
              $A(str.split("\n")).each( function(l) {
                  
                  linecount += Math.ceil( l.length / cols ); // Take into account long lines
              })
              $('post_text').rows = linecount + 1;
            };

            // You could attach to keyUp, etc. if keydown doesn't work
            Event.observe('post_text', 'keydown', resizeIt );

            resizeIt(); //Initial on load
            writeIt = function(){
              $('post_text').style='border: 1px solid #00AACF;width:95% '
            }
        </script>
</body></html>