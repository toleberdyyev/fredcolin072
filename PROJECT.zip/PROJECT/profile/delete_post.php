<?php 
$post_id=$_GET['id_post'];
include '../db.php';
$sql=mysql_query("DELETE FROM posts WHERE id='$post_id'");
header("location:index.php");
?>