<!--  PROFILE  -->
<html><head>

<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Ubuntu&subset=cyrillic' rel='stylesheet' type='text/css'>

<style type="text/css">
  body{
background-color: #3E3E3E !important;
font-family: 'Ubuntu', sans-serif !important;

}.col-md-3{
  border-radius: 5px 0px 0px 5px !important;
  background-color: white !important; 
}.col-md-5{
  margin-left: -8px;
}#panel{
  margin-left: 5px !important;
  margin-bottom: 5px;
  background-color: white !important;
  padding-bottom: 7px;
  margin-left: 0px !important;

}
.navbar{

  border: hidden !important;
  box-shadow: 0em 0.4em 15px #000000 !important;
}.row{
  margin: auto!important;
}#save{
  width: 50px;
  border-radius: 25px;
  margin: auto;
  border: 3px solid #009966;
  padding: 10px 10px 10px 10px;
}.choose{

}#upload{
  background-color: #337CBB;
  border: hidden;
  color: white;
}

  
</style>
    <title>My Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="profile.css" rel="stylesheet" type="text/css">
  </head>
<?php
session_start();
include "../db.php";
$log= $_SESSION['login'];
$result=mysql_query("SELECT * FROM users WHERE login='$log'",$db);
$myrow=mysql_fetch_array($result);
if (empty($_SESSION['login']) or empty($_SESSION['id'] or empty($_SESSION['password'])) )
{
header("location:../index.php");
}             
?>
  <body>
    <div class="navbar navbar-default navbar-static-top" class="navbar">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
          <a class="navbar-brand" href="home.php">www.Bidaction.kz</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
          <li>
              <a href="../home.php">Main page</a> 
            </li>
            <li>
              <a href="../game_dev/index.php">Game dev</a> 
            </li>
           
            <li>
              <a href="index.php" style="color:#337CBB;">@<?php echo $_SESSION['login']." ";?></a>
            </li>
            
          
            
          </ul>
        </div>
      </div>
    </div>
    <div class="section">       
      <div class="container">
        <div class="row">
          <div class="col-md-2 col-sm-1">
          </div>
          <div class="col-md-3 col-sm-4">
          <br>
<?php 
include "upld.php";
?>

            <center>
              <img src='<?php echo $myrow["photo_back"]; ?>' class="img-responsive img-thumbnail centerimg" style=""><br>
              <br>

<form action="profile_settings.php" method="post" enctype="multipart/form-data">

<input type="file" name="fileToUpload1" id="fileToUpload1" class="choose" value="Фото"></input>
<input type="submit" value="Upload Image" name="submit" class="form-control" id="upload">
</form> 

<hr>
<img src='<?php echo $myrow["photo"]; ?>' class="img-responsive img-thumbnail centerimg" style=""><br>
              <br> 
<form action="profile_settings.php" method="post" enctype="multipart/form-data">
<input type="file" name="fileToUpload" id="fileToUpload" class="choose" value="Фото"></input>
<input type="submit" value="Upload Image" name="submit" class="form-control" id="upload">
</form>  
<center><a href="index.php"><input type='image' value='save' id='save' src='user_image/save.png' class=""></a>
</center><br>
    
            </center>
            
          </div>
          <div class="col-md-5 col-sm-6">
          <div class="col-md-12 " id="panel">

          <br>
            <blockquote>
            
              <footer>online</footer>
            </blockquote></div>
<div class="col-md-12 " id="panel">
<h4>Genaral data</h4>
<form>
<div class="col-md-6"><input type="text" class="form-control" name="name" value=<?php echo $myrow['name'];?> placeholder="Имя" required></input></div>
<div class="col-md-6"><input type="text" class="form-control" name='surname' value='<?php echo $myrow['surname'];?>' placeholder="Фамилия" required></input></div><br><br>
<div class="col-md-12"><div class="input-group">
  <span class="input-group-addon" id="basic-addon1">@</span>
  <input type="text" class="form-control" name='login' placeholder="login" value=<?php echo $myrow['login']; ?> required>
</div></div><br><br>
<div class="col-md-12"><input type="text"  name='email' class="form-control" value=<?php echo $myrow['email']; ?> placeholder="exmaple@email.com" required></div><br><br><h4>Personal data</h4>
<div class="col-md-12"><input type="text" name='phone' class="form-control" value=<?php echo $myrow['phone']; ?> placeholder="Телефон" required></div><br><br>
<div class="col-md-12"><input type="date" class="form-control" id="birthDate" name="age" required="" ></div><br><br>
<div class="col-md-12">
     <?php
        $Array = array('Алматы',"Шымкент",'Астана','
Караганда',"Актобе",'Тараз',"Павлодар","Семей","Усть-Каменогорск","Кызылорда","Уральск","Костанай","Атырау","Петропавловск","Актау","Темиртау","Кокшетау","Туркестан","Экибастуз","Талдыкорган","Рудный","Жанаозен");
        ?>
        <select class="form-control input-sm" name="city" value=<?php echo $myrow['city']; ?> required="">
        <option  value=<?php echo $myrow['city']; ?>>Укажите ваш город</option>
        <?php foreach($Array as $value){ echo('<option value="' . $value . '">' . $value . '</option>');}?>
        </select>
</div><br><br>
<center><input type='image' value='save' id='save' src='user_image/save.png'>
</center>
          </div>





</script>


             
             </div>

                <div class="col-md-1 col-sm-1"></div>
              </li>
            </ul>
          </div>
          <br><br>
        </div>
      </div>

    </div>
  

</body></html>