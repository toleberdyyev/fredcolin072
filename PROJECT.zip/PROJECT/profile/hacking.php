<!--  PROFILE  -->
<html><head>
<meta charset="utf-8">
<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Ubuntu&subset=cyrillic' rel='stylesheet' type='text/css'>

<style type="text/css">
  body{
background-color: #3E3E3E !important;
font-family: 'Ubuntu', sans-serif !important;
}.text-primary{
  font-family: arial !important;
}.col-md-3.col-sm-4{
  border-radius: 5px 0px 0px 5px !important;
  background-color: white !important; 
    padding-left: 0px;
  padding-right: 0px;
}.col-md-5{
  margin-left: -8px;
}#panel{
  margin-left: 5px !important;
  border-radius: 0px 5px 0px 0px!important;
  background-color: white !important;
  padding-bottom: 7px;

  margin-left: 0px !important;

}
.navbar{
  position: fixed !important;
  width: 100%;
  border: hidden !important;
  box-shadow: 0em 0.4em 8px #000 !important;
}.row{
  margin: auto!important;
}#cancel{
  width: 85px;
  float: left !important;
  background-color: #337CBB; 
  color: white;
  border: hidden;
  margin-top: -10px;
}.delete_post{
  float: left; 
  background-color: #eaeaea;
  color: #666666;
  border-radius: 0px 0px 3px 3px;  
  border:hidden;
  margin-top: -15px;
  opacity: 0.5;
  width: 25px;
}.delete_post:hover{
  background-color:#ff4d4d;
  color: white;
  opacity: 1;
}#ava_back{

  
  display: inline-block;
  width: 100%;
  height:200px;
  background-position: center center;
  background-size: cover;
}#ava{
  margin-top: -25px !important;
  border:5px solid white;
  border-radius: 50px;
  display: inline-block;
  width: 100px;
  height: 100px;
  margin-top: 5px;
  background-position: center center;
  background-size: cover;
 
  
}#post{
  background-color: white;
  margin-top: 5px;
  height: auto;
}#post textarea{
  padding: 15px 8px 15px 8px;
  background-color: #F5F5F5;
}.post_time{
  font-size: 13px;
  color:#337CBB;
  margin-top: -8px;
  padding-left: 70px; 
}#post_text{
  resize: none;
  font-size: 15px;

}.post_pole{
  
  border-radius: 3px 3px 3px 0px !important;

}#edit{
  border: hidden;
  border-radius: 0px 0px 3px 3px;

}#save{
  border: 1px solid #eaeaea;
  border-radius: 0px 0px 3px 3px;
  float: right;
  background-color:white;
  height: 23px;
  padding: 0px 2px 0px 2px; 
  margin-right: 3px;
}#save:hover{
    box-shadow: 0em 0.2em 5px rgba(122,122,122,0.5);

}.login_in_post{
  padding-left:70px;
  padding-bottom:-55px;
  padding-top: 5px;
font-family: 'Ubuntu', sans-serif;
font-weight: 500;
}.footer{
  margin: auto;
}.thumb{ 

   
    display: inline-block;
    width: 100%;
    height:50px;
    margin-bottom: -59px;
    margin-top: 5px;
    background-position: center center;
    background-size: cover;
    padding: 0px;
}.edit_btn:hover{
  opacity: 1;
}.answers li { 
list-style: upper-alpha; 
} 

  
</style>
    <title>My Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="profile.css" rel="stylesheet" type="text/css">
  </head>
<?php
session_start();
include "../db.php";
$id=$_SESSION['id'];
$user_id=$_POST['user_id'];

$result=mysql_query("SELECT * FROM users WHERE id='$id'",$db);
$myrow=mysql_fetch_array($result);



if (empty($_SESSION['login']) or empty($_SESSION['id'] or empty($_SESSION['password'])) )
{
header("location:../index.php");
}             
?>
  <body onload="timer_three()">
    <div class="navbar navbar-default navbar-static-top" class="navbar">
      <div class="container">
        <div class="navbar-header" >
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
          <a class="navbar-brand" href="home.php"><h3 style="margin-top: -11px;"><img style="margin-top:-5px;width: 50px;" src="user_image/small_logo.png">hackount.kz</h3></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li>
             <?php 
             echo "<a href='user_profile.php?id=".$user_id."'> leave</a>";
            
              ?>
            </li>
            <li>
              <a href="index.php" style="color:#337CBB;">@<?php echo $myrow['login'] ?></a>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="section">       
      <div class="container"><br><br>
        <div class="row">
      
     <div class="col-md-3"></div>
     <div class="col-md-6" style="background-color: white;padding: 0px;"> <div id="ava_back" style="background-image: url(http://cd8ba0b44a15c10065fd-24461f391e20b7336331d5789078af53.r23.cf1.rackcdn.com/iphonedevsdk.vanillaforums.com/editor/c3/qip5srlh9ux8.gif)" title="It is me"><center>
     <span id="timer" ></span></center></div>
  <?php 
include "../db.php";
// make th first easy questions for our users
$result_a=mysql_query("SELECT * FROM admin_orders where level='easy' ORDER BY RAND() LIMIT 0,1",$db);
$myrow_a=mysql_fetch_array($result_a);
$a=array($myrow_a['qt'],$myrow_a['f1'],$myrow_a['f2'],$myrow_a['f3']);
shuffle($a);
// second
$result_b=mysql_query("SELECT * FROM admin_orders where level='normal' ORDER BY RAND() LIMIT 0,1",$db);
$myrow_b=mysql_fetch_array($result_b);
$b=array($myrow_b['qt'],$myrow_b['f1'],$myrow_b['f2'],$myrow_b['f3']);
shuffle($b);
// third
$result_c=mysql_query("SELECT * FROM admin_orders where level='hard' ORDER BY RAND() LIMIT 0,1",$db);
$myrow_c=mysql_fetch_array($result_c);
$c=array($myrow_c['qt'],$myrow_c['f1'],$myrow_c['f2'],$myrow_c['f3']);
shuffle($c);



?>
    <br>
    
    
    
      <form action="finish_game.php" method="post" id="myform">
      <input type="hidden" name="id" value="<?php echo $user_id; ?>"></input>
            <ol style="padding-right: 40px;">
            
                <li>
                
                    <h3><?php echo $myrow_a['question']; ?></h3>
                    <input type="hidden" name="1_q_id" value="<?php echo $myrow_a['id']; ?>"></input>
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-A" value="A" />
                        <label for="question-1-answers-A">A) <?php echo $a[0]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-B" value="B" />
                        <label for="question-1-answers-B">B) <?php echo $a[1]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-C" value="C" />
                        <label for="question-1-answers-C">C) <?php echo $a[2]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-D" value="D" />
                        <label for="question-1-answers-D">D) <?php echo $a[3]; ?></label>
                    </div>
                
                </li>
                
                <li>
                
                    <h3><?php echo $myrow_b['question']; ?></h3>
                     <input type="hidden" name="1_q_id" value="<?php echo $myrow_b['id']; ?>"></input>
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-A" value="A" />
                        <label for="question-2-answers-A">A) <?php echo $b[0]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-B" value="B" />
                        <label for="question-2-answers-B">B) <?php echo $b[1]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-C" value="C" />
                        <label for="question-2-answers-C">C) <?php echo $b[2]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-D" value="D" />
                        <label for="question-2-answers-D">D) <?php echo $b[3]; ?></label>
                    </div>
                
                </li>
                
                <li>
                
                    <h3><?php echo $myrow_c['question']; ?></h3>
                     <input type="hidden" name="1_q_id" value="<?php echo $myrow_c['id']; ?>"></input>
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-A" value="A" />
                        <label for="question-3-answers-A">A) <?php echo $c[0]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-B" value="B" />
                        <label for="question-3-answers-B">B) <?php echo $c[1]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-C" value="C" />
                        <label for="question-3-answers-C">C) <?php echo $c[2]; ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-D" value="D" />
                        <label for="question-3-answers-D">D) <?php echo $c[3]; ?></label>
                    </div>
                
                </li>
                <hr>
                </ol>
                  <span id='go_btn'><input type="submit" class="form-control" value="Hack!"  style="background-color: #303A4E;color:white;border:hidden;width: 30%;margin: auto;" /></span>
                </form>
    
      <div id="ava_back" style="background-image: url(http://cd8ba0b44a15c10065fd-24461f391e20b7336331d5789078af53.r23.cf1.rackcdn.com/iphonedevsdk.vanillaforums.com/editor/c3/qip5srlh9ux8.gif)" title="It is me"><center>
     <span id="timer2" ></span></center></div>
     </div>

     <div class="col-md-3"></div>
          </div>
          <br><br>
        </div>
      </div>

    </div>
  <script type="text/javascript">
var timer_three=function(){
var i=11
var starTimer=function(){
i--
document.getElementById('timer').innerHTML="<h1 style='margin-top: 50px!important;margin: auto;font-size: 80px;color:white;'>"+i+" seconds.<h1>"
document.getElementById('timer2').innerHTML="<h1 style='margin-top: 50px!important;margin: auto;font-size: 80px;color:white;'>"+i+" seconds.<h1>"
if (i==0){
document.getElementById('timer').innerHTML="<h1 style='margin-top: 50px!important;margin: auto;font-size: 80px;color:white;'>Time is up<h1>"
document.getElementById('timer2').innerHTML="<h1 style='margin-top: 50px!important;margin: auto;font-size: 80px;color:white;'>Time is up<h1>"
document.getElementById('go_btn').innerHTML='<input type="submit" class="form-control" value="leave"  style="background-color: #303A4E;color:white;border:hidden;width: 30%;margin: auto;" />'

document.getElementById("myform").action = "user_profile.php";

}

else{setTimeout(starTimer,1000)}
}
setTimeout(starTimer,0)
}


  </script>

</body></html>