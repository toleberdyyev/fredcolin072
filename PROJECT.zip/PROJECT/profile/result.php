 <?php
session_start();
$id=$_SESSION['id'];
$servername = "localhost";
$username = "root";
$password = "123";
$dbname = "bidaction";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$index=0;
$sql = " SELECT * FROM posts WHERE user='$id'ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $index++;
        echo '<div  id="post" style="padding:10px ;background-color:white;border-top:10px solid ##3E3E3E;">
        <div class="thumb" style="background-image: url(http://localhost/PROJECT/profile/'.$myrow['photo'].');" title="It is me"></div>
<h4 class="login_in_post">@'.$_SESSION['login'].'</h4><p class="post_time"> #  '.$row['p_date'].'</p>

        <form methode="post" action="edit_post.php">
             <span id="span">
             <textarea name="post_text" rows="3"  cols="160" value="'.$row["p_text"].'" readonly class="form-control"  id="'.$index.'_text"  style="overflow:hidden;resize:none;border:1px solid #eaeaea;padding:10px;border-radius:0;"  maxlength="140">'.$row["p_text"].'</textarea>
             </span>
            <button type="button" id="'.$index.'_index" onclick="edsit(this)" style="opacity:0.5;border-radius: 0px 0px 3px 3px;border:hidden;font-size:12px;float:right;background-color: #eaeaea;color: #666666;"><img src="user_image/edit.png" style="width:20px;" class="edit_btn"></button>
            <input type="hidden" name="id_post" value="'.$row['id'].'">
            <span id="'.$index.'"></span>
        </form>
       
        <form post="post" action="delete_post.php">
                <input type="hidden" name="id_post" value="'.$row['id'].'">
                <input type="image" value="удалить" src="user_image/delete.png"class="delete_post"></input>
        </form><br></div>
        ';
        
    }
} else {
    echo "<br>";
    echo "<center> <p style='color:#888686;'>Ваша стена пуста :(</p></center>";
}
$conn->close();
?>