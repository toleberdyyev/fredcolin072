<?php 
session_start();
$status="ofline";
$user_id=$_SESSION['id'];
include "../db.php";
$sql=mysql_query("UPDATE bidaction.users SET online_status='$status'  WHERE users.id='$user_id' ");
header("location:total_logout.php")


?>	