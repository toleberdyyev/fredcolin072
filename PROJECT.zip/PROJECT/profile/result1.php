 <?php
session_start();
$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "123";
$dbname = "bidaction";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$index=0;
$sql = " SELECT * FROM posts WHERE user='$id'ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $index++;
        echo '<div class="col-md-12 col-sm-12" id="post">
        <div class="thumb" style="background-image: url(http://localhost/PROJECT/profile/'.$myrow['photo'].');" title="It is me"></div>
<h4 class="login_in_post">@'.$row['login'].'</h4><p class="post_time"> #  '.$row['p_date'].'</p>

        <form methode="post" action="edit_post.php">
             <span id="span">
             <textarea name="post_text" rows="3"  cols="160" value="'.$row["p_text"].'" readonly class="form-control"  id="'.$index.'_text"  style="overflow:hidden;resize:none;border:1px solid #eaeaea;border-radius:0;"  maxlength="140">'.$row["p_text"].'</textarea>
             </span>
           
       
       <br></div>
        ';
        
    }
} else {
    echo "<br>";
    echo "<center> <p style='color:#888686;'>Ваша стена пуста :(</p></center>";
}
$conn->close();
?>