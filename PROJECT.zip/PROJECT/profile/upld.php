
<?php
session_start();
include "../db.php";
$id=$_SESSION['id'];
$target_dir = "uploads/";
//$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$nameoffile=basename($_FILES['fileToUpload']['name']);

$uploadOk = 1;
//$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

// Check if image file is a actual image or fake image
if(isset($_FILES['fileToUpload'])){
    $imageFileType = pathinfo($_FILES["fileToUpload"]["name"],PATHINFO_EXTENSION);
$target_file = $target_dir. $id.".".$imageFileType;
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
if(empty($_FILES["fileToUpload"])){}else{
// Check if file already exists
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000 and $uploadOk==1) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
        $url=$target_file;
        $sql=mysql_query("UPDATE bidaction.users SET photo='$url'  WHERE users.id='$id' ");
        
        $id=$_SESSION['id'];
        $servername = "localhost";
        $username = "root";
        $password = "123";
        $dbname = "bidaction";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        
        $sql = " SELECT * FROM posts WHERE user='$id'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $sql001=mysql_query("UPDATE bidaction.posts SET photo='$url'  WHERE posts.user='$id' ");

        }
        } else {
        echo "<br>";
        echo "<center> <p style='color:#888686;'>Ваша стена пуста :(</p></center>";
        }
        $conn->close();
        header('location:refresh.php');
        

    } else {
        echo "Sorry, there was an error uploading your file.";
        
    }
}}}


if(isset($_FILES['fileToUpload1'])){
    $imageFileType = pathinfo($_FILES["fileToUpload1"]["name"],PATHINFO_EXTENSION);
$target_file = $target_dir. $id."_back.".$imageFileType;
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload1"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
if(empty($_FILES["fileToUpload1"])){}else{
// Check if file already exists
// Check file size
if ($_FILES["fileToUpload1"]["size"] > 500000 and $uploadOk==1) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload1"]["name"]). " has been uploaded.";
        $url=$target_file;
        $sql=mysql_query("UPDATE bidaction.users SET photo_back='$url'  WHERE users.id='$id' ");
        header("location:refresh.php");


    } else {
        echo "Sorry, there was an error uploading your file.";
        
    }
}}}

?>
