<html><head>
<title>hackount.kz</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<style type="text/css">
body{
font-family: arial !important;
font-weight: normal !important;

}.text-center{
font-family: arial !important;
color: white !important;
}
</style>
</head><body>
<div class="cover">
<div class="background-image-fixed cover-image" style="background-image : url('http://www.designvertise.com/wp-content/uploads/2014/05/Space-45-Night-by-Seth-Eckert.gif')"></div>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="section">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1 class="text-center">Добро пожаловать на
<br>
<b class="bid">Bidaction</b>
</h1>
 <h2 class="text-center">Пройдите<br>Регистраицию</h2>
<div class="section">
<div class="container">
<div class="row">
<div class="col-md-4 hidden-xs"></div>
<div class="col-md-4 login-box">
<br>
<!DOCTYPE html>
   <html>
   <head>
        <meta charset="utf-8">
       <title></title>
   </head>
   <body><?php   
$f_name=$_POST['f_name'];
$l_name=$_POST['l_name'];//NAME  I FAMIL
//=====DATA=====
$name=$f_name;
$sname=$l_name;// ALL FAMILY NAME
$login=$_POST['login'];//login
$email=$_POST['email'];// EMAIL
$password=$_POST['password'];// PASSWORD
$r_password=$_POST['r_password'];//REPEAT A PASSWORD
$age=$_POST['age'];// USER AGE
$phone=$_POST['phone'];//USER PHONE NUMBER
$city=$_POST['city'];//USER CITY
$status=0;
//если логин и пароль введены, то обрабатываем их, чтобы теги и скрипты не работали, мало ли что люди могут ввести
$name = stripslashes($name);$name = htmlspecialchars($name);
$sname = stripslashes($sname);$sname = htmlspecialchars($sname);
$login=stripcslashes($login);$login=htmlspecialchars($login);
$email = stripslashes($email);$email = htmlspecialchars($email);
$password = stripslashes($password);$password = htmlspecialchars($password);
$r_password = stripslashes($r_password);$r_password = htmlspecialchars($r_password);
$age = stripslashes($age);$age = htmlspecialchars($age);
$phone = stripslashes($phone);$phone = htmlspecialchars($phone);
$city = stripslashes($city);$city = htmlspecialchars($city);
 //удаляем лишние пробелы
$name = trim($name);
$sname = trim($sname);
$login=trim($login);
$email = trim($email);
$password = trim($password);
$r_password = trim($r_password);
$age = trim($age);
$phone = trim($phone);
$city = trim($city);
$photo="user_image/avatar.png";
$photo_back="user_image/ava_back.png";

include "db.php";//тут короче подключаемся и после проверяем на емаил твоего акк...
$result =  mysql_query("SELECT id FROM users WHERE email='$email'",$db);
$myrow = mysql_fetch_array($result);
if (!empty($myrow['id'])) {
echo("Извините, введённый вами e-mail уже зарегистрирован. Введите другой.<br>");
}else{
    $result1= mysql_query("SELECT id FROM users WHERE login='$login'",$db);
    $myrow1=mysql_fetch_array($result1);
    if(!empty($myrow1['id'])){echo "Извините, введённый вами логин уже используется.";
    }else{  //=====DATA=====
// PASSWORD VALIDATION CHEACKER
if( strlen($password) < 6 ) {$error .= "* Пароль минимум из 6-ти символов<br> ";}
if( strlen($password) > 20 ) {$error .= "* Пароль Максимум из 20-ти символов<br> ";}
if( !preg_match("#[0-9]+#", $password) ) {$error .= "* Пароль должен содержать хотя бы одну цифру(0-9)<br>";}
if( !preg_match("#[a-z]+#", $password) ) {$error .= "* Пароль должен содержать прописную (a-z)<br>";}
if( !preg_match("#[A-Z]+#", $password) ) {$error .= "* Пароль должен содержать заглавную (A-Z)<br>";}
if(strlen($phone)< 10){$error.="* Телефон минимум из 11-ти символов<br>";}
if(strlen($phone)> 12){$error.="* Телефон Максимум из 12-ти символов<br>";}
if($error){echo "<b>В ходе регистрации были найди ошибки:</b><p style='color:EA4335;font-size:15px;'><br> $error</p>";} 
else {
    if ($r_password==$password){
// если такого нет, то сохраняем данные
$result2 = mysql_query ("INSERT INTO users (id,name,surname,login,email,password,age,phone,city,photo,photo_back,online_status) VALUES(NULL,'$name','$sname','$login','$email','$password','$age','$phone','$city','$photo','$photo_back','$status')")or die(mysql_error());
// Проверяем, есть ли ошибки
if ($result2=='TRUE')
{
echo "<center><img src='img/accept.ico' style='width:75px;height:75px   ;'></center>";
echo '<br><b>Большое Спасибо за регистрацию :)</b><br>Теперь вы можете зайти на сайт.<br>Перейти на страницу <a href="index.php"style="color:#5BC0DE;"><b>Войти</b></a><br>';
}
else {
echo "Ошибка! Вы не зарегистрированы.";}}}}}
?>   
<br>
<input class="form-control" type="button" onclick="history.back()" value="Back" style="background-color: #5BC0DE;color: white;border:hidden;">
<br>
</div>
<div class="col-md-4 hidden-xs"></div>
</div></div></div></div></div>
</div></div></div></div></div>
</div>

</body></html>