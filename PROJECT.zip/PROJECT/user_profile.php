<!--  PROFILE  -->
<html><head>

<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Ubuntu&subset=cyrillic' rel='stylesheet' type='text/css'>

<style type="text/css">
  body{
background-color: #3E3E3E !important;
font-family: 'Ubuntu', sans-serif !important;
}.text-primary{
  font-family: arial !important;
}.col-md-3.col-sm-4{
  border-radius: 5px 0px 0px 5px !important;
  background-color: white !important; 
    padding-left: 0px;
  padding-right: 0px;
}.col-md-5{
  margin-left: -8px;
}#panel{
  margin-left: 5px !important;
  border-radius: 0px 5px 0px 0px!important;
  background-color: white !important;
  padding-bottom: 7px;

  margin-left: 0px !important;

}
.navbar{
  position: fixed !important;
  width: 100%;
  border: hidden !important;
  box-shadow: 0em 0.4em 8px #000 !important;
}.row{
  margin: auto!important;
}#cancel{
  width: 85px;
  float: left !important;
  background-color: #337CBB; 
  color: white;
  border: hidden;
  margin-top: -10px;
}.delete_post{
  float: left; 
  background-color: #eaeaea;
  color: #666666;
  border-radius: 0px 0px 3px 3px;  
  border:hidden;
  margin-top: -15px;
  opacity: 0.5;
  width: 25px;
}.delete_post:hover{
  background-color:#ff4d4d;
  color: white;
  opacity: 1;
}#ava_back{
 border-radius:4px 0px 0px 0px !important;
  
  display: inline-block;
  width: 100%;
  height:135px;
  background-position: center center;
  background-size: cover;
}#ava{
  margin-top: -25px !important;
  border:5px solid white;
  border-radius: 50px;
  display: inline-block;
  width: 100px;
  height: 100px;
  margin-top: 5px;
  background-position: center center;
  background-size: cover;
 
  
}#post{
  background-color: white;
  margin-top: 5px;
  height: auto;
}#post textarea{
  padding: 15px 8px 15px 8px;
  background-color: #F5F5F5;
}.post_time{
  font-size: 13px;
  color:#337CBB;
  margin-top: -8px;
  padding-left: 70px; 
}#post_text{
  resize: none;
  font-size: 15px;

}.post_pole{
  
  border-radius: 3px 3px 3px 0px !important;

}#edit{
  border: hidden;
  border-radius: 0px 0px 3px 3px;

}#save{
  border: 1px solid #eaeaea;
  border-radius: 0px 0px 3px 3px;
  float: right;
  background-color:white;
  height: 23px;
  padding: 0px 2px 0px 2px; 
  margin-right: 3px;
}#save:hover{
    box-shadow: 0em 0.2em 5px rgba(122,122,122,0.5);

}.login_in_post{
  padding-left:70px;
  padding-bottom:-55px;
  padding-top: 5px;
font-family: 'Ubuntu', sans-serif;
font-weight: 500;
}.footer{
  margin: auto;
}.thumb{ 
    border:3px solid #eaeaea;
    border-radius: 3p2x;
    display: inline-block;
    width: 64px;
    height: 64px;
    margin-bottom: -59px;
    margin-top: 5px;
    background-position: center center;
    background-size: cover;
}.edit_btn:hover{
  opacity: 1;
}

  
</style>
    <title>My Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="profile.css" rel="stylesheet" type="text/css">
  </head>
<?php
session_start();
include "../db.php";
$log= $_SESSION['login'];
$result=mysql_query("SELECT * FROM users WHERE login='$log'",$db);
$myrow=mysql_fetch_array($result);
$ava=$myrow['photo'];
$back=$myrow['photo_back'];

if (empty($_SESSION['login']) or empty($_SESSION['id'] or empty($_SESSION['password'])) )
{
header("location:../index.php");
}             
?>
  <body>
    <div class="navbar navbar-default navbar-static-top" class="navbar">
      <div class="container">
        <div class="navbar-header" >
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>

            </button>
          <a class="navbar-brand" href="home.php">www.Bidaction.kz</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="../home.php">Главная</a> 
            </li>
           
            <li class="active dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" style="color:#337CBB;">@<?php echo $_SESSION['login']." ";?><i class="fa fa-caret-down"><br></i></a>
              <ul class="dropdown-menu" role="menu" style="border: hidden;">
                <li>
                  <a href="logout.php">Выйти</a>
                </li>
                <li>
                  <a href="profile_settings.php"><img src="user_image/settings.png" style="width: 20px;float: right;">Настройки</a>
                </li>
              </ul>
            </li>
          
            
          </ul>
        </div>
      </div>
    </div>
    <div class="section">       
      <div class="container"><br><br>
        <div class="row">
          <div class="col-md-2 col-sm-1">
          </div>
          <div class="col-md-3 col-sm-4">
          
            
            <div id="ava_back" style="background-image: url(http://localhost/PROJECT/profile/<?php echo $back;?>" title="It is me"></div><center>
            <div>
                <div id="ava" style="background-image: url(http://localhost/PROJECT/profile/<?php echo $ava;?>" title="It is me"></div>
            </div>
           
            

              <h3 class="text-primary"><?php echo $myrow['name']."<br>".$myrow['surname'];?></h3>
              <br>
              <table class="table">
                <thead>
                  <tr></tr>
                </thead>
                <tbody>
                  <tr>
                    <td><b>Телефон</b></td>
                    <td><?php echo $myrow['phone']; ?></td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td><b>Возраст</b></td>
                    <td><?php echo $myrow['age']; ?></td>
                  </tr>
                  <tr>
                    <td><b>Город</b></td>
                    <td><?php echo $myrow['city']; ?></td>
                  </tr>
                </tbody>
              </table>  
            </center>
            
          </div>
          <div class="col-md-5 col-sm-6">
          <div class="col-md-12 " id="panel">

          <br>
            <blockquote style="background-color: #F8F8FA">
              <p>Admin</p>
              <footer>online</footer>
            </blockquote>
            <table class="table" style="background-color: #F8F8FA">
                <tr>
                  <td>My Auction:</td>
                  <td>empty</td>
                </tr>
                <tr>
                  <td>My Orders</td>
                  <td>empty</td>
                </tr>
                <tr>
                  <td>My total purchase</td>
                  <td>empty</td>
                </tr>
            </table>
      
      <form method="post" action="save.php">


   <textarea class="form-control input-sm" type="text"  rows ="3" id="post_text"  maxlength="138" name="post_text" placeholder="Что у вас нового ?"></textarea><br><span id="demo"><input class="form-control" name="enter" type="submit" id="cancel" value="отправить">
   <br>

  

</form>
</div>
<?php 
  include "result.php";  
  ?>
<script type="text/javascript">
function edsit(o){
  var id_index= o.id
  var id= id_index.substring(0,1)
  var id_text=id+"_text"
  console.log(id)
  o.style.opacity=1;
  document.getElementById(id).innerHTML="<input type='image' value='save' id='save' src='user_image/save.png'>"
  document.getElementById(id_text).readOnly = false;
  document.getElementById(id_text).style.background="white";
}
</script>


             
             </div>

                <div class="col-md-1 col-sm-1"></div>
              </li>
            </ul>
          </div>
          <br><br>
        </div>
      </div>

    </div>
  

</body></html>