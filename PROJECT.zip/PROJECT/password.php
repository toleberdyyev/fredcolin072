<form name=”form” action=”" method=”post“>
<input type=”password” name=”pass1“onKeyUp=”passValid(’form’,'pass1′,’pass12′,’submit’),isRavno(’form’,'pass1′,’pass2′,’pass22′,’submit’)“> - Введите пароль
<span id=”pass11” >< span id=”pass12” ></span></span><br />

<input type=”password” name=”pass2” onKeyUp=”isRavno(’form’,'pass1′,’pass2′,’pass22′,’submit’)“> - Повторите пароль

<span id=”pass22” >< /span>< br />

<input type=”submit” name=”submit” value=”Далее” disabled><br />
</form>


