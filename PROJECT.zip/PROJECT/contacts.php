<html><head>
        <title>Bidaction | Contacts</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
        <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="contacts.css" rel="stylesheet" type="text/css">
    </head><body>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="home.php">www.BidAction.kz</a>
                </div>
                <div class="collapse navbar-collapse" id="navbar-ex-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="home.php">Home</a>
                        </li>
                        <li>
                            <a href="profile.php">Profile</a>
                        </li>
                        <li>
                            <a href="sell.php">Sell</a>
                        </li>
                        <li class="active">
                            <a href="contacts.php">Contacts</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="cont contact section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center text-primary">Contacts</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4">
                        <ul class="media-list">
                            <li class="media">
                                <a class="pull-left" href="#"><img class="img-rounded media-object" src="email.png" height="64" width="64"></a>
                                <div class="media-body">
                                    <h3 class="media-heading" contenteditable="true">email</h3>
                                    <p>bidaction@money.com</p>
                                </div>
                            </li>
                            <li class="media">
                                <a class="pull-left" href="#"><img class="media-object" src="phone.png" height="64" width="64"></a>
                                <div class="media-body">
                                    <h3 class="media-heading" contenteditable="true">Phone number</h3>
                                    <p>8 775 501 10 50</p>
                                </div>
                            </li>
                        </ul>
                        <ul class="media-list text-left">
                            <li class="media">
                                <a class="pull-left" href="#"><img class="media-object" src="adress.png" height="64" width="64"></a>
                                <div class="media-body">
                                    <h3 class="media-heading" contenteditable="true">Media heading</h3>
                                    <p>Kazakhstan / Almaty region / Kaskelen / Abylaihana 1\1</p>
                                </div>
                            </li>
                            <li class="media"></li>
                        </ul>
                    </div>
                    <div class="col-md-4"></div>
                </div>
            </div>
        </div>
        <div class="cover">
            <div class="cover-image" style="background-image : url('https://unsplash.imgix.net/photo-1418065460487-3e41a6c84dc5?w=1024&amp;q=50&amp;fm=jpg&amp;s=127f3a3ccf4356b7f79594e05f6c840e')"></div>
        </div>
    

</body></html>