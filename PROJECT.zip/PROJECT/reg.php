<html><head>
<title>hackount.kz</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<style type="text/css">
body{
font-family: arial !important;
font-weight: normal !important;

}.text-center{
font-family: arial !important;
color: white !important;
}
</style>
</head><body>
<div class="cover">
<div class="background-image-fixed cover-image" style="background-image : url('http://www.designvertise.com/wp-content/uploads/2014/05/Space-45-Night-by-Seth-Eckert.gif')"></div>
<div class="container"> 
<div class="row">
<div class="col-md-12">
<div class="section">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1 class="text-center">

<img src="profile/user_image/logo_white.png" style="width: 100px;"><br>
Welcome to<br>
<b class="bid">hackount.kz</b>
</h1>
                     <h2 class="text-center"><b>registration</b></h2>
<div class="section">
<div class="container">
<div class="row">
<div class="col-md-4 hidden-xs"></div>
<div class="col-md-4 login-box">
<br>
<form action="save_user.php" method="post" >
<!--**** save_user.php - это адрес обработчика. То есть, после нажатия
на кнопку "Зарегистрироваться", данные из полей отправятся на страничку
save_user.php методом "post" ***** -->
<label class="control-label size">Your full name ?
    <div class="row">
        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group">
                <input type="text" name="f_name" class="form-control input-sm" placeholder="name" required="">
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group">
                <input type="text" name="l_name" class="form-control input-sm" placeholder="surname" required="">
            </div>
        </div>
    </div>
    <p class="name-input">
        <label class="control-label size">Your login</label>
        <input name="login"  class="form-control input-sm" type="text" placeholder="login" required="">

    </p>
    <p class="name-input">
        <label class="control-label size">Your email</label>
        <input name="email"  class="form-control input-sm" type="email" placeholder="example@email.com" required="">

    </p>
    <?php
    function CheckEmail()
    {
         $email = $_POST['email'];
         $query = @mysql_query("SELECT email FROM users WHERE email='" . $email . "'");
         $a = mysql_num_rows($query);
         while($row = mysql_fetch_array($query)){
            if($row['email'] == $email){
                "Email you entered is already registered";
            }
         }
    } ?>
    <label class="control-label size">Your password</label>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">

                    <input type="password" id="password"name="password" class="form-control input-sm" placeholder="create a password" required="">
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                   <input type="password" id="password2" name="r_password" class="form-control input-sm" placeholder="repeat a password" equired=""><span id="valid3"></span>
                </div>
            </div>
        </div>
        <div id="err"></div>
        
        <!--**** В текстовое поле (name="login" type="text") пользователь вводит
        свой логин ***** -->
       
        <label class="control-label size">Your birth date</label><br>
        <input type="date" class="form-control" id="birthDate" name="age" required="">
        <br>

    <p class="name-input">
        <label class="control-label size">Your phone number</label>
        <input name="phone"  class="form-control input-sm" type="tel" placeholder="+7 700 700 70 70" required="">
    </p>
    
     <label class="control-label size">Your city</label><br>
   <?php
        $Array = array('Almaty',"Shymkent",'Astana','
Karaganda',"Aktobe",'Taraz',"Pavlodar","Semey","Ust-kamenogorsk","Kyzylorda","Uralsk","Kostanai","Atyrau","Petropavlosk","Aktau","Temirtau","Kokshetau","Turkestan","Ekibastuz","Taldykorgan","Rudany","Zhanaozen");
        ?>
        <select class="form-control input-sm" name="city" required="">
        <option value="">Select your city</option>
        <?php foreach($Array as $value){ echo('<option value="' . $value . '">' . $value . '</option>');}?>
        </select>
        <hr>
        <p class="lead rebbtn text-info">
            <input class="form-control" type="submit" name="submit" value="Registrate" style="background-color: #5BC0DE;color: white;border:hidden;">
            <!--**** Кнопочка (type="submit") отправляет данные на страничку save_user.php
            ***** -->
        </p>

        <div class="col-md-12 text-center">
            <a href="index.php"><i class="-o-notch fa fa-5x fa-chevron-circle-right fa-fw fa-rotate-180 text-info"></i></a>
        </div>
        <br>
        <br>
        <br>
        <br>
    </label>
</label>
</form>
</div>
<div class="col-md-4 hidden-xs"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="valiid.js"></script>
</body></html>