  <head>
    <meta charset="utf-8">
  </head>
  <?php 
include "db.php";

$result=mysql_query("SELECT * FROM admin_orders where author='toleberdyyev' ORDER BY RAND() LIMIT 0,1",$db);
$myrow=mysql_fetch_array($result);
echo 'question : '.$myrow['question']."<br>";
$a=array($myrow['qt'],$myrow['f1'],$myrow['f2'],$myrow['f3']);
shuffle($a);
foreach ($a as $i ) {
  echo $i."<br>";
  
 
}

?>