<head>
	<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
</head>
<form>
	<p><input id=password><span id="valid2"></span></input></p>
	<p><input id=password2><span id="valid3"></span></input></p>
</form>
<script src="valiid.js"></script>