<html><head>
<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Ubuntu&subset=cyrillic' rel='stylesheet' type='text/css'>
<link rel="shortcut icon" href="profile/user_image/logo_white.png" type="image/png">
<style type="">
  body{
background-color: #3E3E3E !important;
font-family: 'Ubuntu', sans-serif !important;
}.text-primary{
  font-family: arial !important;
}.col-md-3.col-sm-4{
  border-radius: 5px 0px 0px 5px !important;
  background-color: white !important; 
    padding-left: 0px;
  padding-right: 0px;
}.col-md-5{
  
}#panel{
  margin-left: 5px !important;
  border-radius: 0px 5px 0px 0px!important;
  background-color: white !important;
  padding-bottom: 7px;

  margin-left: 0px !important;

}
.navbar{
  position: fixed !important;
  width: 100%;
  border: hidden !important;
  box-shadow: 0em 0.4em 8px #000 !important;
}.row{
  margin: auto!important;
}#cancel{
  width: 85px;
  float: left !important;
  background-color: #337CBB; 
  color: white;
  border: hidden;
  margin-top: -10px;
}.delete_post{
  float: left; 
  background-color: #eaeaea;
  color: #666666;
  border-radius: 0px 0px 3px 3px;  
  border:hidden;
  margin-top: -15px;
  opacity: 0.5;
  width: 25px;
}.delete_post:hover{
  background-color:#ff4d4d;
  color: white;
  opacity: 1;
}#ava_back{
 border-radius:4px 0px 0px 0px !important;
  
  display: inline-block;
  width: 100%;
  height:135px;
  background-position: center center;
  background-size: cover;
}#ava{
  margin-top: -25px !important;
  border:5px solid white;
  border-radius: 50px;
  display: inline-block;
  width: 100px;
  height: 100px;
  margin-top: 5px;
  background-position: center center;
  background-size: cover;
 
  
}#post{
  background-color: white;
  padding: 10px !important;
  padding: 0;
  margin-top: -2px;
  height: auto;

  border-top: 2px solid #3E3E3E;
}#post textarea{
  padding: 15px 8px 15px 8px;
  background-color: white;
}.post_time{
  font-size: 13px;
  color:#337CBB;
  margin-top: -8px;
  padding-left: 70px; 
}#post_text{
  resize: none;
  font-size: 15px;

}.post_pole{
  
  border-radius: 3px 3px 3px 0px !important;

}#edit{
  border: hidden;
  border-radius: 0px 0px 3px 3px;

}#save{
  border: 1px solid #eaeaea;
  border-radius: 0px 0px 3px 3px;
  float: right;
  background-color:white;
  height: 23px;
  padding: 0px 2px 0px 2px; 
  margin-right: 3px;
}#save:hover{
    box-shadow: 0em 0.2em 5px rgba(122,122,122,0.5);

}.login_in_post{
  padding-left:70px;
  padding-bottom:-55px;
  padding-top: 5px;
font-family: 'Ubuntu', sans-serif;
font-weight: 500;
color: #121A5A;
}.footer{
  margin: auto;
}.thumb{ 
    
    border-radius: 22px;
    display: inline-block;
    width: 44px;
    height: 44px;
    margin-bottom: -59px;
    margin-top: 10px;
    margin-left: 10px;
    background-position: center center;
    background-size: cover;
}.edit_btn:hover{
  opacity: 1;
}


</style>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="home.css" rel="stylesheet" type="text/css">
  </head>
<?php
session_start();
include "db.php";
$log= $_SESSION['login'];
$result=mysql_query("SELECT * FROM users WHERE login='$log'",$db);
$myrow=mysql_fetch_array($result);
$ava=$myrow['photo'];
$back=$myrow['photo_back'];

if (empty($_SESSION['login']) or empty($_SESSION['id'] or empty($_SESSION['password'])) )
{
header("location:index.php");
}             
?>

 <body>
    <div class="navbar navbar-default navbar-static-top" class="navbar">
      <div class="container">
        <div class="navbar-header" >
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>

            </button>
         <a class="navbar-brand" href="home.php"><h3 style="margin-top: -11px;"><img style="margin-top:-5px;width: 50px;" src="profile/user_image/logo_white.png">hackount.kz</h3></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="active">
              <a href="home.php">Main page</a> 
            </li>
             <li >
              <a href="game_dev/index.php" >Game dev</a> 
            </li>
            
            <li>
              <a href="profile/index.php" style="color:#337CBB;">@<?php echo $myrow['login']; ?></a> 
            </li>
        </div>
      </div>
    </div>
    <div class="section">       
      <div class="container"><br><br>
      <div class="row">
        <div class="col-md-2"></div>
          <div class="col-md-8">
            <form  action="home.php" method="post" class="col-md-12" style="width:100%">
              <input type="text"  name='search'placeholder=" write a login to find a user" style="display: inline-block;width: 75%;border:hidden;height:30px; border-radius: 3px 0 0 3px;padding-left: 10px;"><br>
              <input type="submit"  value="search"  style="float: right;margin-top: -30px;width: 25%;border:hidden;height:30px;border-radius: 0 3px 3px 0;background-color:#34A853;color:white;">
             
            </form>
          </div>
          <div class="col-md-2"></div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-1">
          </div>
          <div class="col-md-3 col-sm-4 hidden-xs " >
          
            
            <div id="ava_back" style="background-image: url(http://localhost/PROJECT/img/Space-45-Night-by-Seth-Eckert.gif" title="It is me"></div><center>
            <div>
                <div id="ava" style="background-image: url(http://localhost/PROJECT/profile/<?php echo $ava;?>" title="It is me"></div>
            </div>
           
            

              <h3 class="text-primary" style="color:#337CBB;"><?php echo $myrow['name']."<br>".$myrow['surname'];?></h3>
              <br>
              
            </center>
            
          </div>
          <div class="col-md-5 col-sm-6 " style="padding: 0px;border-left:2px solid #3E3E3E  !important; ">
       <?php
session_start();
$servername = "localhost";
$username = "root";
$password = "123";
$dbname = "bidaction";
$search=$_POST['search'];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
if (empty($_POST['search'])){
$sql = " SELECT * FROM posts ORDER BY id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
while($row = $result->fetch_assoc()) {
if ($_SESSION['id']==$row['user']){
 echo '<div class="col-md-12"  id="post" ><a href="profile/index.php">
<div class="thumb" style="background-image: url(http://localhost/PROJECT/profile/'.$row['photo'].'" title="It is me"></div>
<h4 class="login_in_post">@'.$row['login'].'</h4></a></form><p class="post_time"> #  '.$row['p_date'].'</p>

<form methode="post" action="edit_post.php">
<span id="span">
<textarea name="post_text" rows="3"  cols="160" value="'.$row["p_text"].'" readonly class="form-control"  id="'.$index.'_text"  style="overflow:hidden;resize:none;border:1px solid #eaeaea;border-radius:0;color:#405A77"  maxlength="140">'.$row["p_text"].'</textarea>
</span>
<input type="hidden" name="id_post" value="'.$row['id'].'">
<span id="'.$index.'"></span>
</form>

</div>
<br>
';

}else{
echo '<div class="col-md-12"  id="post" ><a href="profile/user_profile.php?id='.$row['user'].'">
<div class="thumb" style="background-image: url(http://localhost/PROJECT/profile/'.$row['photo'].'" title="It is me"></div>
<h4 class="login_in_post">@'.$row['login'].'</h4></a></form><p class="post_time"> #  '.$row['p_date'].'</p>

<form methode="post" action="edit_post.php">
<span id="span">
<textarea name="post_text" rows="3"  cols="160" value="'.$row["p_text"].'" readonly class="form-control"  id="'.$index.'_text"  style="overflow:hidden;resize:none;border:1px solid #eaeaea;border-radius:0;color:#405A77"  maxlength="140">'.$row["p_text"].'</textarea>
</span>
<input type="hidden" name="id_post" value="'.$row['id'].'">
<span id="'.$index.'"></span>
</form>

</div>
<br>
';}

}} else {
echo "<br>";
echo "<center> <p style='color:#888686;'>Ваша лента пуста :(</p></center>";
}}
else{
  
  $searcher=substr($search, 0,2);
  

  $sql = " SELECT * FROM users WHERE login LIKE '$searcher%' ORDER BY login ASC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
while($row = $result->fetch_assoc()) {
if ($_SESSION['id']==$row['user']){
  echo '<div class="col-md-12"  id="post" >
<a href="profile/index.php">
<div class="thumb" style="background-image: url(http://localhost/PROJECT/profile/'.$row['photo'].'" title="It is me"></div>
<h4 class="login_in_post">@'.$row['login'].'</a></h4><p class="post_time"> '.$row['online_status'].'</p>
</div><br>';
}else{
    echo '<div class="col-md-12"  id="post" >
<a href="profile/user_profile.php?id='.$row['id'].'">
<div class="thumb" style="background-image: url(http://localhost/PROJECT/profile/'.$row['photo'].'" title="It is me"></div>
<h4 class="login_in_post">@'.$row['login'].'</a></h4><p class="post_time"> '.$row['online_status'].'</p>
</div><br>';

}

}
}else{
  echo "<br>";
echo "<center> <p style='color:#888686;'>Sorry, по вашему запросу нечего не найдено :(</p></center>";
}}
$conn->close();
?>
             </div>

                <div class="col-md-1 col-sm-1"></div>
              </li>
            </ul>
          </div>
          <br><br>
        </div>
      </div>

    </div>
  
 <script type="text/javascript" language="javascript">
            resizeIt = function() {
              var str = $('post_text').value;
              var cols = $('post_text').cols;

              var linecount = 0;
              $A(str.split("\n")).each( function(l) {
                  
                  linecount += Math.ceil( l.length / cols ); // Take into account long lines
              })
              $('post_text').rows = linecount + 1;
            };

            // You could attach to keyUp, etc. if keydown doesn't work
            Event.observe('post_text', 'keydown', resizeIt );

            resizeIt(); //Initial on load
            writeIt = function(){
              $('post_text').style='border: 1px solid #00AACF;width:95% '
            }
        </script>
</body></html>