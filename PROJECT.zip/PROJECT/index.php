<html><head>
<link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Ubuntu&subset=cyrillic' rel='stylesheet' type='text/css'>
<title>hackount.kz</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<style type="text/css">
body{
font-family: 'Ubuntu', sans-serif !important;

}.text-center{
font-family: arial !important;
color: white !important;

}.bid{
text-shadow: 2px 2px 15px #000000 !important;
}
</style>
</head><body>
<?php 
session_start();
?>
<!--?php // вся процедура работает на сессиях. Именно в ней хранятся данные
пользователя, пока он находится на сайте. Очень важно запустить их в самом
начале странички!!! session_start(); ?-->
<div class="cover">
<div class="background-image-fixed cover-image" style="background-image : url('http://www.designvertise.com/wp-content/uploads/2014/05/Space-45-Night-by-Seth-Eckert.gif')"></div>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="section">
<div class="container">
<div class="row">
<div class="col-md-12">

<h1 class="text-center">
<img src="profile/user_image/logo_white.png" style="width: 100px;"><br>
<b class="bid">hackount.kz</b>
</h1>
<div class="section">
<div class="container">
    <div class="row">
        <div class="col-md-4 hidden-xs"></div>
        <div class="col-md-4 login-box">
            <br>
            <form action="test_reg.php" method="post">
                <!--**** save_user.php - это адрес обработчика. То есть, после нажатия
                на кнопку "Зарегистрироваться", данные из полей отправятся на страничку
                save_user.php методом "post" ***** -->
                <p class="name-input">
                    <label class="control-label size">Your login</label>
                    <input name="login" id="na" class="form-control input-sm" type="text" placeholder="login" required="">
                </p>
                <p class="name-input">
                    <label class="control-label size">Your password</label>
                    <input name="password" id="na" class="form-control input-sm" type="password" placeholder="password" required="">
                </p>
                <p class="lead rebbtn text-info">
                    <!--**** В поле для паролей (name="password" type="password") пользователь
                    вводит свой пароль ***** -->
                    <input class="form-control" id=" " type="submit" name="submit" value="login" style="background-color: #5BC0DE;color: white;border:hidden;">
                    <!--**** Кнопочка (type="submit") отправляет данные на страничку save_user.php
                    ***** -->
                </p>
                <hr>
                 <?php

            // Проверяем, пусты ли переменные логина и id пользователя
            if (empty($_SESSION['login']) or empty($_SESSION['id']) )
            {
            print_r(' <p>Hello ! your welcome to visit our brain hacking website <b>hackount.kz</b><br>click below to registrate, and have fun :)<br><a href="reg.php"style="color:#5BC0DE;">sign up</a> </p>


             ');
            echo "<br>";
            }
            else
            {

            // Если не пусты, то мы выводим ссылку
            echo "<p style='color:#303030;font-size:17px;'>Войти под именем <b ><a href='profile/index.php' style='color:#5BC0DE;'>".$_SESSION['login']."<a></b><br><a href='profile/logout.php'>выйти из акаунта</a><br>
            или пройти <a href='reg.php'style='color:#5BC0DE;'><b>регистрацию</b></a>
            </p>";
            header("location:profile/logout.php");
            }
            ?>
            </form>
        </div>
        <div class="col-md-4 hidden-xs"></div>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


</body></html>