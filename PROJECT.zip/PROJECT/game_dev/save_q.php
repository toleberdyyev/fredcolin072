<?php
session_start();
include '../db.php';
$question= $_POST['question'];
$qt = $_POST['qt'];
$f1 = $_POST['f1'];
$f2 = $_POST['f2'];
$f3 = $_POST['f3'];
$username=$_SESSION['login'];
$question = stripslashes($question);$question = htmlspecialchars($question);$question = trim($question);
$qt = stripslashes($qt);$qt = htmlspecialchars($qt);$qt = trim($qt);
$f1 = stripslashes($f1);$f1 = htmlspecialchars($f1);$f1 = trim($f2);
$f2 = stripslashes($f2);$f2 = htmlspecialchars($f2);$f2= trim($f2);
$f3 = stripslashes($f3);$f3 = htmlspecialchars($f3);$f3 = trim($f3);

echo $question." ".$qt.' '.$f1.' '.$f2.' '.$f3;
$sql=mysql_query("INSERT INTO admin_orders (id,question,qt,f1,f2,f3,author,checked) VALUES(NULL,'".addslashes($question)."','".addslashes($qt)."','".addslashes($f1)."','".addslashes($f2)."','".addslashes($f3)."','$username',0)"); 
if($sql=='TRUE'){
  header('location:index.php?uploaded=true');
}


 ?>