 <form action="save_q.php" method="post"><br>
    <ul>If you want to be a part of hacount.kz  just develop a question by yourself. It's so ezyy :)<br><br>
      <li> first <b>create a question</b> for hacking.<br>
           <textarea  onclick="writeIt()"class="form-control input-sm" rows='1'type="text"   id="post_text"  name="question" placeholder="your question ..." style="resize: none !important;width:95%;" required=""></textarea>
      </li><br>

      <li>then think up <b style="color: #34A853">ONE TRUE </b>
        <input class="form-control" name='qt'style="border:1px solid #34A853;width: 95%;" placeholder="your true answer" required=""></input>
      </li><br>
      <li>and <b style="color: #EA4335">THREE FALSE</b> answers</li>
      <input class="form-control" name="f1" style="border:1px solid #EA4335;width: 95%;" placeholder="your 1'st false answer" name="f2"></input><br>
      <input class="form-control" style="border:1px solid #EA4335;width: 95%;" placeholder="your 2'nd false answer" name="f2" required=""></input><br>
      <input class="form-control" style="border:1px solid #EA4335;width: 95%;" placeholder="your 3'rd false answer" name="f3" required=""></input><br>
       <input  type='submit' class="form-control" value="upload a question" style="color: white ;background-color: #337CC9;width: 50%"></input>
       <hr style="width: 95%">
    </ul><br>
   </form>